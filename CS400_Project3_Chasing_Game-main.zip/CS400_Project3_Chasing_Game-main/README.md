# CS400_Project3_Chasing_Game

## Basic Gameplay
### Characters
1. Player
2. Hunter
### Constructors on Edges
1. Grass (cost 2)
2. Obstacle (cost 3)
3. Road (cost 1)

### Operation in Each Turn
#### At the beginning of each turn
`playerStrength` self increment by 3 (is cumulative)

`playerObstacleStorage` set to 2

`playerRoadStorage` set to 1

`hunterStrength` self increment by 3 (is cumulative)

#### After the hunter make his movement

player can build constructors near his node

player can move

